CountriesList = []
def Start():
    Choice = int(input("Would you like to add a country, or wipe the file? (1/2) \n"))
    if Choice == 1:
        AddCountry()
    elif Choice == 2:
        ClearTXT()
    else:
        print("Error, pick 1 or 2")
        Start()

        
def ClearTXT():
    with open('List.txt','r+') as Txt:
        Txt.truncate(0)


def AddCountry():
    for x in range(5):
        CountriesList.append(str(input("Input a country to add: ")))
    WriteTXT(CountriesList)

def WriteTXT(X):
    with open('List.txt','w') as Txt:
        for item in CountriesList:
            Txt.write("%s\n" % item)


Start()
